// missing __erasure_code_version

int __this_is_an_used_variable_to_avoid_warnings;
